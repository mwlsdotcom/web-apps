var total = 0;
var units = 0;
var runningStrength = 0;
var runningVolume = 0;

const now = new Date();
var dayName;
var day;
var month;
var year;

function init() {
	
	if (localStorage.getItem('total') == null) {
		total = 0;
	}
	else {
		total = localStorage.getItem('total');
	}
	
	document.getElementById("totalUnits").innerHTML = total;
	
	if (localStorage.getItem('date') == null) {
		startDate = currentDate();
	}
	else {
		startDate = localStorage.getItem('date');
	}
	
	document.getElementById("sinceDate").innerHTML = startDate;
    
}

function increaseVolume() {
	var volume = runningVolume;
	volume = Number(volume) + 5;
	document.getElementById("vol").value = volume;
	showValue1(volume);
}

function decreaseVolume() {
	var volume = runningVolume;
	volume = Number(volume) - 5;
	document.getElementById("vol").value = volume;
	showValue1(volume);

}

function increaseStrength() {
	var streng = runningStrength;
	streng = Number(streng) + .1
	streng = streng.toFixed(1);
	showValue2(streng);
}

function decreaseStrength() {
	var streng = runningStrength;
	streng = Number(streng) - .1
	streng = streng.toFixed(1);
	showValue2(streng);
}

function calc() {
	
	units = runningVolume * runningStrength * .001;
	units = units.toFixed(1);
	
	if (units == 1) {
		document.getElementById("display").innerHTML = "Your drink has 1 unit";
	}
	else {
		document.getElementById("display").innerHTML = "Your drink has " + units + " units";
	}
	
}

function showValue1(newValue) {
	runningVolume = newValue;
	document.getElementById("range1").innerHTML = newValue;
	newValue=newValue/28.41;
	newValue = newValue.toFixed(0);
	document.getElementById("range1oz").innerHTML = newValue;
	document.getElementById("ukvol").value = "uk";
	document.getElementById("winevol").value = "wine";
	calc()
}

function showValue2(newValue) {
	runningStrength = newValue;
	document.getElementById("range2").innerHTML = newValue;
	calc()
}

function setUkVolume() {
	
	if (document.getElementById("ukvol").value != "uk") {
		newVol = document.getElementById("ukvol").value;
	}
	
    document.getElementById("vol").value = newVol;
    showValue1(newVol);
    
}

function setWineVolume() {
	if (document.getElementById("winevol").value != "wine") {
		newVol = document.getElementById("winevol").value;
	}
    document.getElementById("vol").value = newVol;
	showValue1(newVol);
}

function addToTotal() {
	total = Number(total) + Number(units);
	total = total.toFixed(1);
	document.getElementById("totalUnits").innerHTML = total;
	localStorage.setItem('total', total);
}

function reset() {
	
	total = 0;
	document.getElementById("totalUnits").innerHTML = total;
	localStorage.setItem('total', total);
	
	startDate = currentDate();
	
	document.getElementById("sinceDate").innerHTML = startDate;
	localStorage.setItem('date', startDate);
	
}

function currentDate() {
	day = dayName(now.getDay());
	monthDay = now.getDate();
	month = monthName(now.getMonth());
	year = now.getFullYear();
	startDate = day + " " + monthDay + " " + month + " " + year;
	return startDate;
}

function monthName(monthNum) {
	months=new Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	month = months[monthNum];
	month = month.substring(0, 3);
	return month;
}

function dayName(dayNum) {
	days=new Array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday");
	day = days[dayNum];
	day = day.substring(0, 3);
	return day;
}
