<style>
body {
    /* background-color: rgb(0,122,255) #4682B4*/;
    /* color: white;  #222 Foreground color used for text */
    font-family: Verdana, sans-serif;
    font-size: 12pt;
    margin: 0;
    padding: 0;
}

.select-style select {
	font-size: 15px;
	background-image: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#ccc));
}

input[type=button] {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	font-weight:bold;
	-webkit-border-radius:8px;
	-moz-border-radius:8px;
	margin-top:10px;
	margin-bottom:15px;
	padding:3px;
	background-image: -webkit-gradient(linear, left top, left bottom, from(#fff), to(#ccc));
	border:1px solid black;
}

input[type='range'] {
    -webkit-appearance: none !important;
    background: silver /*(rgb(92,148,252)*/;
    height:5px;
    width:295px;
    margin-top:20px;
    margin-bottom:15px;
}

input[type="range"]::-webkit-slider-thumb {
     -webkit-appearance: none;
    background-color: rgb(158,173,202);
    opacity: 1.0;
    width: 28px;
    height: 28px;
    -webkit-border-radius: 14px;
}
</style>
